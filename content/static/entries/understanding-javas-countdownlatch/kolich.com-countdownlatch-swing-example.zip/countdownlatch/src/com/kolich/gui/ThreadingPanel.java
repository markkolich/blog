package com.kolich.gui;

import java.awt.Color;

import javax.swing.JPanel;

public class ThreadingPanel extends JPanel {

	private static final long serialVersionUID = -4763661368269807175L;

	public ThreadingPanel() {
		super();
		setOpaque(true);
		setBackground(Color.WHITE);
	}
	
}
