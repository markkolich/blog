#include <conio>
#include <dice>
#include <apmatrix.h>

void output_board(apmatrix<int> board);
void output_grid();
void startup(apmatrix<int> & board);
void reset(apmatrix<int> & board);
void human(apmatrix<int> & board);
void computer(apmatrix<int> & board);
void draw(apmatrix<int> & board);
void win(apmatrix<int> & board);
void play(apmatrix<int> & board);
void score_output();

void o();
void ix();

int long score = 0;

int blk = 219;
char block = blk;
int blk2 = 176 + 2;
char scb = blk2;

int const BLANK = 5;
int const O_VALUE = 20;

main()
{
   apmatrix<int> board(3,3,BLANK);
   
   
   textcolor(WHITE);

   startup(board);

   play(board);
   exit(1);
}

void play(apmatrix<int> & board)
{
	bool x = true;
   int player = 1;

   clrscr();
   reset(board);
   output_grid();
   output_board(board);

  	while(x)
   {
     	human(board);
     	win(board);
     	computer(board);
     	win(board);
     	output_board(board);
   }

} // end play();


void draw(apmatrix<int> & board)
{
   board[1][1] = BLANK;
   output_board(board);

   gotoxy(35,11);
   textcolor(14);
   cprintf("TIC TAC TOE");

   gotoxy(38,13);
   cprintf("DRAW!");
   gotoxy(29,15);
   cprintf("Press enter to continue!");
   gotoxy(29,16);
   cprintf("  Press zero to quit!   ");

   score_output();
   gotoxy(40,11);

   while(!kbhit())
   	;

   play(board);
}

void startup(apmatrix<int> & board)
{
 	board[0][0] = 1;
   board[0][1] = O_VALUE;
   board[0][2] = 1;

   board[1][0] = O_VALUE;
   board[1][1] = BLANK;
   board[1][2] = O_VALUE;

   board[2][0] = 1;
   board[2][1] = O_VALUE;
   board[2][2] = 1;

   output_grid();
   output_board(board);

   gotoxy(35,11);
   textcolor(14);
   cprintf("TIC TAC TOE");

   gotoxy(31,13);
   cprintf("(c) 2001 Mark Kolich");
   gotoxy(31,14);
   cprintf("  Ver 2.0   Build 8  ");
   gotoxy(30,16);
   cprintf("Press any key to begin!");
   gotoxy(40,11);

   while(!kbhit())
   	;
}


void win(apmatrix<int> & board)
{
	int r1, r2, r3;
   int c1, c2, c3;
   int x1, x2;

   r1 = board[0][0] + board[1][0] + board[2][0];
   r2 = board[0][1] + board[1][1] + board[2][1];
   r3 = board[0][2] + board[1][2] + board[2][2];
   c1 = board[0][0] + board[0][1] + board[0][2];
   c2 = board[1][0] + board[1][1] + board[1][2];
   c3 = board[2][0] + board[2][1] + board[2][2];
   x1 = board[0][0] + board[1][1] + board[2][2];
   x2 = board[2][0] + board[1][1] + board[0][2];

   if((r1 == 3) || (r2 == 3) || (r3 == 3) || (c1 == 3) || (c2 == 3) || (c3 == 3)
   || (x1 == 3) || (x2 == 3))
   {
      board[1][1] = BLANK;
   	output_board(board);

   	gotoxy(35,11);
   	textcolor(14);
   	cprintf("TIC TAC TOE");

   	gotoxy(37,13);
   	cprintf("YOU WON!");
      gotoxy(29,15);
   	cprintf("Press enter to continue!");
   	gotoxy(29,16);
   	cprintf("  Press zero to quit!   ");

      score = score + 100;
      score_output();

      gotoxy(40,11);

   	while(!kbhit())
   		;

   	play(board);
   }
   else if((r1 == 60) || (r2 == 60) || (r3 == 60) || (c1 == 60) || (c2 == 60) || (c3 == 60)
   || (x1 == 60) || (x2 == 60))
   {
      board[1][1] = BLANK;
   	output_board(board);

   	gotoxy(35,11);
   	textcolor(14);
   	cprintf("TIC TAC TOE");

   	gotoxy(36,13);
   	cprintf("YOU LOST!");
      gotoxy(29,15);
   	cprintf("Press enter to continue!");
   	gotoxy(29,16);
   	cprintf("  Press zero to quit!   ");

      score = score - 100;
      score_output();

      gotoxy(40,11);

   	while(!kbhit())
   		;

   	play(board);
   }
   else
   	;
}




void human(apmatrix<int> & board)
{
	int input = getch();

   if((input != 48) && (input != 55) && (input != 56) && (input != 57) &&
   (input != 52) && (input != 53) && (input != 54) && (input != 49) &&
   (input != 50) && (input != 51))
   {
    	human(board);
   }
   if(input == 48)
   	exit(1);
   if(input == 55)
   {
    	if(board[0][0] == BLANK)
         board[0][0] = 1;
      else
      	human(board);
   }
   if(input == 56)
   {
    	if(board[1][0] == BLANK)
         board[1][0] = 1;
      else
      	human(board);
   }
   if(input == 57)
   {
    	if(board[2][0] == BLANK)
         board[2][0] = 1;
      else
      	human(board);
   }
   if(input == 52)
   {
    	if(board[0][1] == BLANK)
         board[0][1] = 1;
      else
      	human(board);
   }
   if(input == 53)
   {
    	if(board[1][1] == BLANK)
         board[1][1] = 1;
      else
      	human(board);
   }
   if(input == 54)
   {
    	if(board[2][1] == BLANK)
         board[2][1] = 1;
      else
      	human(board);
   }
   if(input == 49)
   {
    	if(board[0][2] == BLANK)
         board[0][2] = 1;
      else
      	human(board);
   }
   if(input == 50)
   {
    	if(board[1][2] == BLANK)
         board[1][2] = 1;
      else
      	human(board);
   }
   if(input == 51)
   {
    	if(board[2][2] == BLANK)
         board[2][2] = 1;
      else
      	human(board);
   }
}


void computer(apmatrix<int> & board)
{
	dice col(3);
   dice row(3);
   bool roll = true;

   int r1, r2, r3;
   int c1, c2, c3;
   int x1, x2;

   int r, c, t = 0;

   r1 = board[0][0] + board[1][0] + board[2][0];
   r2 = board[0][1] + board[1][1] + board[2][1];
   r3 = board[0][2] + board[1][2] + board[2][2];

   c1 = board[0][0] + board[0][1] + board[0][2];
   c2 = board[1][0] + board[1][1] + board[1][2];
   c3 = board[2][0] + board[2][1] + board[2][2];

   x1 = board[0][0] + board[1][1] + board[2][2];
   x2 = board[2][0] + board[1][1] + board[0][2];

   while(roll)
   {

   /*
   if((board[1][1] == BLANK) && ((board[0][0] == 1) || (board[2][0] == 1) || (board[2][2] == 1) || (board[0][2] == 1)))
   {
      if(board[1][1] == BLANK) {	board[1][1] = O_VALUE;	roll = false; }
   }
	else
   {
   */

   if(((r1 == 45) || (r2 == 45) || (r3 == 45) || (c1 == 45) || (c2 == 45) || (c3 == 45) || (x1 == 45) || (x2 == 45)))
   {
      if(r1 == 45)
      {
          if(board[0][0] == BLANK) {	board[0][0] = O_VALUE;	roll = false; }
          else if(board[1][0] == BLANK) { board[1][0] = O_VALUE; roll = false; }
          else if(board[2][0] == BLANK) {	board[2][0] = O_VALUE; roll = false; }
      }
      else if(r2 == 45)
      {
          if(board[0][1] == BLANK) { board[0][1] = O_VALUE; roll = false; }
          else if(board[1][1] == BLANK) { board[1][1] = O_VALUE; roll = false; }
          else if(board[2][1] == BLANK) {	board[2][1] = O_VALUE; roll = false; }
      }
      else if(r3 == 45)
      {
          if(board[0][2] == BLANK) { board[0][2] = O_VALUE; roll = false; }
          else if(board[1][2] == BLANK) { board[1][2] = O_VALUE; roll = false; }
          else if(board[2][2] == BLANK) { board[2][2] = O_VALUE; roll = false; }
      }
      else if(c1 == 45)
      {
          if(board[0][0] == BLANK) {	board[0][0] = O_VALUE; roll = false; }
          else if(board[0][1] == BLANK) { board[0][1] = O_VALUE; roll = false; }
          else if(board[0][2] == BLANK) {	board[0][2] = O_VALUE; roll = false; }
      }
      else if(c2 == 45)
      {
          if(board[1][0] == BLANK) {	board[1][0] = O_VALUE; roll = false; }
          else if(board[1][1] == BLANK) { board[1][1] = O_VALUE; roll = false; }
          else if(board[1][2] == BLANK) {	board[1][2] = O_VALUE; roll = false; }
      }
      else if(c3 == 45)
      {
          if(board[2][0] == BLANK) {	board[2][0] = O_VALUE; roll = false; }
          else if(board[2][1] == BLANK) { board[2][1] = O_VALUE; roll = false; }
          else if(board[2][2] == BLANK) { board[2][2] = O_VALUE; roll = false; }
      }
      else if(x1 == 45)
      {
          if(board[0][0] == BLANK) {	board[0][0] = O_VALUE; roll = false; }
          else if(board[1][1] == BLANK) { board[1][1] = O_VALUE; roll = false; }
          else if(board[2][2] == BLANK) { board[2][2] = O_VALUE; roll = false; }
      }
      else if(x2 == 45)
      {
          if(board[2][0] == BLANK) {  board[2][0] = O_VALUE; roll = false; }
          else if(board[1][1] == BLANK) { board[1][1] = O_VALUE; roll = false; }
          else if(board[0][2] == BLANK) {  board[0][2] = O_VALUE; roll = false; }
      }

      roll = false;
   }
	else if(((r1 == 2) || (r2 == 2) || (r3 == 2) || (c1 == 2) || (c2 == 2) || (c3 == 2) || (x1 == 2) || (x2 == 2)) ||
   (r1 == 7) || (r2 == 7) || (r3 == 7) || (c1 == 7) || (c2 == 7) || (c3 == 7) || (x1 == 7) || (x2 == 7))
   {
      if((r1 == 2) || (r1 == 7))
      {
          if(board[0][0] == 5) {	board[0][0] = O_VALUE;	roll = false; }
          else if(board[1][0] == 5) { board[1][0] = O_VALUE; roll = false; }
          else if(board[2][0] == 5) {	board[2][0] = O_VALUE; roll = false; }
      }
      else if((r2 == 2) || (r2 == 7))
      {
          if(board[0][1] == 5) { board[0][1] = O_VALUE; roll = false; }
          else if(board[1][1] == 5) { board[1][1] = O_VALUE; roll = false; }
          else if(board[2][1] == 5) {	board[2][1] = O_VALUE; roll = false; }
      }
      else if((r3 == 2) || (r3 == 7))
      {
          if(board[0][2] == 5) { board[0][2] = O_VALUE; roll = false; }
          else if(board[1][2] == 5) { board[1][2] = O_VALUE; roll = false; }
          else if(board[2][2] == 5) { board[2][2] = O_VALUE; roll = false; }
      }
      else if((c1 == 2) || (c1 == 7))
      {
          if(board[0][0] == 5) {	board[0][0] = O_VALUE; roll = false; }
          else if(board[0][1] == 5) { board[0][1] = O_VALUE; roll = false; }
          else if(board[0][2] == 5) {	board[0][2] = O_VALUE; roll = false; }
      }
      else if((c2 == 2) || (c2 == 7))
      {
          if(board[1][0] == 5) {	board[1][0] = O_VALUE; roll = false; }
          else if(board[1][1] == 5) { board[1][1] = O_VALUE; roll = false; }
          else if(board[1][2] == 5) {	board[1][2] = O_VALUE; roll = false; }
      }
      else if((c3 == 2) || (c3 == 7))
      {
          if(board[2][0] == 5) {	board[2][0] = O_VALUE; roll = false; }
          else if(board[2][1] == 5) { board[2][1] = O_VALUE; roll = false; }
          else if(board[2][2] == 5) { board[2][2] = O_VALUE; roll = false; }
      }
      else if((x1 == 2) || (x1 == 7))
      {
          if(board[0][0] == 5) {	board[0][0] = O_VALUE; roll = false; }
          else if(board[1][1] == 5) { board[1][1] = O_VALUE; roll = false; }
          else if(board[2][2] == 5) { board[2][2] = O_VALUE; roll = false; }
      }
      else if((x2 == 2) || (x2 == 7))
      {
          if(board[2][0] == 5) {	board[2][0] = O_VALUE; roll = false; }
          else if(board[1][1] == 5) { board[1][1] = O_VALUE; roll = false; }
          else if(board[0][2] == 5) {	board[0][2] = O_VALUE; roll = false; }
      }

      roll = false;
   }
   else
   {

   c = col.roll();
   r = row.roll();

   if(c == 3)
   	c = 0;
   if(r == 3)
   	r = 0;

   if((board[r][c] == BLANK) && (t < 9))
   {
     	board[r][c] = O_VALUE;
      roll = false;
   }
   else if(t == 9)
   	draw(board);
   else
   {
   	roll = true;
      t++;
   }


   }// end main else statement


   // } // end center square else.

   } // end while statement
}



void reset(apmatrix<int> & board)
{
	clrscr();

	board[0][0] = BLANK;
   board[0][1] = BLANK;
   board[0][2] = BLANK;

   board[1][0] = BLANK;
   board[1][1] = BLANK;
   board[1][2] = BLANK;

   board[2][0] = BLANK;
   board[2][1] = BLANK;
   board[2][2] = BLANK;

}








void output_grid()
{
	int q;
   int const LENGTH = 8;
   textcolor(WHITE);

 	for(q = 0; q < LENGTH; q++)
   	cprintf("                          %c                          %c                         \r\n",block,block);

   for(q = 0; q < 80; q++)
   	cprintf("%c",block);

   for(q = 0; q < LENGTH; q++)
   	cprintf("                          %c                          %c                         \r\n",block,block);

   for(q = 0; q < 80; q++)
   	cprintf("%c",block);

   for(q = 0; q < 6; q++)
   	cprintf("                          %c                          %c                         \r\n",block,block);

   cprintf("                          %c                          %c                         ",block,block);

   gotoxy(26,1);
   cprintf("7");
   gotoxy(53,1);
   cprintf("8");
   gotoxy(80,1);
   cprintf("9");

   gotoxy(80,10);
   cprintf("6");
   gotoxy(53,10);
   cprintf("5");
   gotoxy(26,10);
   cprintf("4");


   gotoxy(80,19);
   cprintf("3\r");
   gotoxy(53,19);
   cprintf("2");
   gotoxy(26,19);
   cprintf("1");



}



void output_board(apmatrix<int> board)
{
	for(int x = 0; x < 3; x++)
   {
    	for(int y = 0; y < 3; y++)
      {
       	if(board[x][y] == 1)
         {
          	if(x==0 && y==0)
            {
            	gotoxy(7,1);
               ix();
            }
            if(x==1 && y==0)
            {
             	gotoxy(35,1);
               ix();
            }
            if(x==2 && y==0)
            {
             	gotoxy(62,1);
               ix();
            }
            if(x==0 && y==1)
            {
            	gotoxy(7,10);
               ix();
            }
            if(x==1 && y==1)
            {
             	gotoxy(35,10);
               ix();
            }
            if(x==2 && y==1)
            {
             	gotoxy(62,10);
               ix();
            }
            if(x==0 && y==2)
            {
            	gotoxy(7,19);
               ix();
            }
            if(x==1 && y==2)
            {
             	gotoxy(35,19);
               ix();
            }
            if(x==2 && y==2)
            {
             	gotoxy(62,19);
               ix();
            }
         } // end x statement
         if(board[x][y] == O_VALUE)
         {
          	if(x==0 && y==0)
            {
            	gotoxy(7,1);
               o();
            }
            if(x==1 && y==0)
            {
             	gotoxy(35,1);
               o();
            }
            if(x==2 && y==0)
            {
             	gotoxy(62,1);
               o();
            }
            if(x==0 && y==1)
            {
            	gotoxy(7,10);
               o();
            }
            if(x==1 && y==1)
            {
             	gotoxy(35,10);
               o();
            }
            if(x==2 && y==1)
            {
             	gotoxy(62,10);
               o();
            }
            if(x==0 && y==2)
            {
            	gotoxy(7,19);
               o();
            }
            if(x==1 && y==2)
            {
             	gotoxy(35,19);
               o();
            }
            if(x==2 && y==2)
            {
             	gotoxy(62,19);
               o();
            }
         } // end o statement
      } // end inner for loop.
   } // end outer for loop.
}


void o()
{
   int x, y;

   textcolor(LIGHTRED);

   cprintf("  ");
   for(int z = 0; z < 8; z++)
      cprintf("%c",scb);

   y = wherey();
   x = wherex();
   gotoxy(x-9,y+1);

   for(int z = 0; z < 10; z++)
      cprintf("%c",scb);


   for(int z = 0; z < 3; z++)
   {
   	y = wherey();
   	x = wherex();
   	gotoxy(x-10,y+1);

      cprintf("%c        %c",scb,scb);
   }


	y = wherey();
   x = wherex();
   gotoxy(x-10,y+1);

  for(int z = 0; z < 10; z++)
      cprintf("%c",scb);

	y = wherey();
   x = wherex();
   gotoxy(x-9,y+1);

   for(int z = 0; z < 8; z++)
      cprintf("%c",scb);
}


void ix()
{
   int x, y;

   textcolor(LIGHTGREEN);

    	cprintf(" %c        %c",scb,scb);

      y = wherey();
   	x = wherex();
   	gotoxy(x-9,y+1);
      cprintf("%c      %c",scb,scb);

      y = wherey();
   	x = wherex();
   	gotoxy(x-7,y+1);
      cprintf("%c    %c",scb,scb);

      y = wherey();
   	x = wherex();
   	gotoxy(x-5,y+1);
      cprintf("%c%c%c%c",scb,scb,scb,scb);

      y = wherey();
   	x = wherex();
   	gotoxy(x-5,y+1);
      cprintf("%c    %c",scb,scb);

      y = wherey();
   	x = wherex();
   	gotoxy(x-7,y+1);
      cprintf("%c      %c",scb,scb);

      y = wherey();
   	x = wherex();
   	gotoxy(x-9,y+1);
      cprintf("%c        %c",scb,scb);
}


void score_output()
{
   textcolor(14);
   gotoxy(30,18);
   cprintf("Score: %i",score);
}

